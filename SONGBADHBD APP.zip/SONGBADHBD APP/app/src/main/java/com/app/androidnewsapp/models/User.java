package com.app.androidnewsapp.models;

import java.io.Serializable;

public class User implements Serializable {

    public String token;
    public String user_unique_id;

}
