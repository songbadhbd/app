package com.app.androidnewsapp.models;

public class Value {

    public String value;
    public String message;

    public String getValue() {
        return value;
    }

    public String getMessage() {
        return message;
    }

}