package com.app.androidnewsapp.callbacks;

import com.app.androidnewsapp.models.User;

public class CallbackUser {

    public String status = "";
    public User response = null;

}