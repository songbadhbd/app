package com.app.androidnewsapp.callbacks;

import com.app.androidnewsapp.models.News;

public class CallbackNewsDetail {

    public String status = "";
    public News post = null;

}